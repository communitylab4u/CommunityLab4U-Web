<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'infomati_romina_torres');

/** MySQL database username */
define('DB_USER', 'infomati_jcampos');

/** MySQL database password */
define('DB_PASSWORD', 'ips017cl');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '.1J+^Wpf-Bn_`qEF6V:Ja%,ldg ?nIs.LDx>;?Umqzz5Hb5fc(lof~Jp+s*;q84Z');
define('SECURE_AUTH_KEY',  '~t?m0BCvZ,n+|Gr%v$qFa^OXJ4tpv4<ObR4kFTnMX2.+FDv)#>{r%106&zN WDZr');
define('LOGGED_IN_KEY',    'Ci~R$LD-| 1xRUpg/cO=LV.A?|Q<7;_xrvt{$Ls`OG7f.E?~_^yXyF8]0k=h@Max');
define('NONCE_KEY',        '^Wxz[DQ?LFlqR)HloDX/I>.$@$MBg-L:l@hL9E$Ipw97^iQrTL<`Y;BF$+WXdi4F');
define('AUTH_SALT',        'jvBjjOE.0;?o5_MQ?<W8O Ej_^H#1*1a[V(Ul[}N<8nO5J}i_{v:IH23 I/bX3D^');
define('SECURE_AUTH_SALT', '[Au~<L&m99b`D(y>Ey-FQ(?d~`(#W11ZODSfFYBQHRcun.!UPgywmV>ORM5{WP.*');
define('LOGGED_IN_SALT',   'v_khz_1nYc[JDB$h#{UCCugf+s2Dqmkq!&m8f;=+T0DTPIbnq){ 7Mf[p~s!$Vl9');
define('NONCE_SALT',       '9d3k&QTsI6i5PXmMQOCx6fWX;G0tPT%1cb.r?;is[L31lsAt+9LuD|Ts^m~[oDZ*');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
